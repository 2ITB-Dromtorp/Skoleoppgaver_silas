const express = require('express')
const app = express()
const port = 3001
var mysql = require('mysql');
var cors = require('cors')
var bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

app.use(cors())

// parse application/json
app.use(bodyParser.json())


var connection = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'root',
  database: 'utlal'
});

connection.connect(function(err) {

  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }

  console.log('connected as id ' + connection.threadId);
});

//Hvis du skal lese noe fra databasen/backend, bruk GET request. 
app.get('/elev', (request, response) => {

  connection.query('SELECT elev.ElevID, elev.Fornavn, elev.Etternavn, klasser.Navn, elev.tlf, elev.epost FROM elev JOIN klasser ON elev.Klasse = klasser.KlasseID;', function (error, results, fields) {
    if (error) throw error;
    response.send(JSON.stringify(results));
    console.log(response)
  });
  
})

app.get('/utstyromm', (request, response) => {

    connection.query('SELECT utstyrsrommet.utstyrID, utstyrsrommet.lanet_av, utstyr_typer.utstyr_type, utstyr_modell.utstyr_modell FROM utstyrsrommet JOIN utstyr_typer ON utstyrsrommet.utstyr_type = utstyr_typer.utsyr_type_ID JOIN utstyr_modell ON utstyrsrommet.utstyr_modell = utstyr_modell.utsyr_modell_ID;', function (error, results, fields) {
      if (error) throw error;
      response.send(JSON.stringify(results));
      console.log(response)
    });
    
})

app.get('/klasser', (request, response) => {

    connection.query('SELECT klasser.KlasseID, klasser.Navn, laerere.FornavnL FROM klasser JOIN laerere ON klasser.Kontakt_laerer = laerere.laererID;', function (error, results, fields) {
      if (error) throw error;
      response.send(JSON.stringify(results));
      console.log(response)
    });
    
})

app.get('/laerere', (request, response) => {

    connection.query('SELECT * FROM laerere', function (error, results, fields) {
      if (error) throw error;
      response.send(JSON.stringify(results));
      console.log(response)
    });
    
})

app.get('/utlan', (request, response) => {

    connection.query('SELECT utlan.UtlanID, elev.Fornavn, elev.Etternavn, utstyr_typer.utstyr_type, utstyr_modell.utstyr_modell, utlan.lanet_ut_dato, laerere.FornavnL FROM utlan JOIN elev ON utlan.lanet_av = elev.ElevID JOIN utstyr_typer ON utlan.utstyr_type = utstyr_typer.utsyr_type_ID JOIN utstyr_modell ON utlan.utsyr_modell_ID = utstyr_modell.utsyr_modell_ID JOIN laerere ON utlan.godkjent_av = laerere.laererID', function (error, results, fields) {
      if (error) throw error;
      response.send(JSON.stringify(results));
      console.log(response)
    });
    
})

app.get('/utstyr_type', (request, response) => {

  connection.query('SELECT * FROM utstyr_typer', function (error, results, fields) {
    if (error) throw error;
    response.send(JSON.stringify(results));
    console.log(response)
  });
  
})

app.get('/utstyr_modell', (request, response) => {

  connection.query('SELECT utstyr_modell.utsyr_modell_ID, utstyr_typer.utstyr_type, utstyr_modell.utstyr_modell FROM utstyr_modell JOIN utstyr_typer ON utstyr_modell.utsyr_type = utstyr_typer.utsyr_type_ID;', function (error, results, fields) {
    if (error) throw error;
    response.send(JSON.stringify(results));
    console.log(response)
  });
  
})

app.post('/insert', async (req, res) => {
  const { key1, key2, key3, key4, key5, key6, key7 } = req.body;
  console.log('received values:', key1, key2, key3, key4, key5, key6, key7);

  let sqlquery = `INSERT INTO utlan(UtlanID, lanet_av, utstyr_type, utsyr_modell_ID, lanet_ut_dato, godkjent_av) VALUES (?,?,?,?,?,?);`;
  let sqlquery2 = `UPDATE utstyrsrommet SET lanet_av = ? WHERE utstyrID = ?;`;

  connection.query(sqlquery, [key1, key2, key3, key4, key5, key6], (err, results, fields) => {
      if (err) {
          console.error(err);
          res.status(500).json({ message: 'Database error' });
          return;
      }

      console.log('First query executed');
      
      connection.query(sqlquery2, [key2, key7], (err, results, fields) => {
          if (err) {
              console.error(err);
              res.status(500).json({ message: 'Database error' });
              return;
          }

          console.log('Second query executed');
          res.status(200).send(JSON.stringify(results));
      });
  });
});

const saltRounds = 10;
const myPlaintextPassword = 'skole123';
const someOtherPlaintextPassword = 'not_bacon';

app.get('/testbcrypt', (req, res) => {

  let sqlquery = `INSERT INTO login(userID, Username, Password, er_laerer, Hash) VALUES (?,?,?,?,?);`;

  bcrypt.hash(myPlaintextPassword, saltRounds, function(err, hash) {
    //console.log(hash)

    /*
    connection.query(sqlquery, [2, 'laerer', 'laerer123', 1, hash], (err, results, fields) => {
      if (err) {
          console.error(err);
          res.status(500).json({ message: 'Database error' });
          return;
      }

      
      console.log('First query executed');
  });
  */
  
    // Store hash in your password DB.
  });

  connection.query('SELECT Hash FROM login', function (err, results) {
    if (err) throw err;
    const user = results[0]
    console.log(user.Hash)

        // Load hash from your password DB.
    bcrypt.compare(myPlaintextPassword, user.Hash, function(err, result) {
      // result == true
      console.log(result)
    });
    
    bcrypt.compare(someOtherPlaintextPassword, user.Hash, function(err, result) {
      // result == false
      console.log(result)
    });
    

  });



  res.send('vi tester bcrypt')
})

app.post('/login', async (req, res) => {

  const { InUsername, InPassword } = req.body;

  console.log(InUsername, InPassword)
  
      if (InUsername && InPassword) {
          connection.query('SELECT Hash, er_laerer FROM login WHERE Username = ?;', [InUsername], async (error, results) => {
              if (error) {
                  console.error(error);
                  return res.status(400).json({ error: 'Internal Server Error' });
              } else {
                  if (results.length>0) {
                      const user = results[0]
                      if (await bcrypt.compare(InPassword, user.Hash)) {
                          const login = true
                          const userTypeID = user.er_laerer
                          console.log(login, userTypeID)
                          res.status(200).send({login, userTypeID})
                      } else {
                          res.status(401).send({ error: 'wrong username and/or password' })
                      }
                  } else {
                      res.status(401).send({ error: 'wrong username and/or password' })
                  }
              }
          });
      } else {
          res.status(401).send({ error: "damn how'd you do that" })
      }

});

app.delete('/delete/:id', (req, res) => {
    const id = req.params.id;
  
    // Corrected SQL query
    const sqlQuery = 'DELETE FROM utlan WHERE UtlanId = ?';
  
    connection.query(sqlQuery, [id], (err, results, fields) => {
      if (err) {
        console.error('Error executing SQL query:', err);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        console.log('SQL query executed successfully:', sqlQuery);
        res.status(200).json({ message: 'Row deleted successfully' });
      }
    });
  });

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})